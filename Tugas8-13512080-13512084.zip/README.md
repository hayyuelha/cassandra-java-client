# Pemrograman Cassandra
Tugas IF4031 Pengembangan Aplikasi Terdistribusi
"Pemrograman Cassandra"

Hayyu' Luthfi Hanifah (13512080)
Choirunnisa Fatima (13512084)

##Petunjuk Instalasi/Building
Pada root direktori, jalankan perintah `mvn clean install package` 

##Petunjuk Menjalankan Program
Untuk menjalankan aplikasi, jalankan perintah `mvn exec:java`

##Daftar Perintah
1. Tweet: `<body tweet>`
2. Follow: `follow <friend>`
3. Timeline: `timeline`
4. Userline: `userline <username>`
5. Logout: `logout`
